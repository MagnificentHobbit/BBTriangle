package triangle;
public class Main {
    public static void main(String[] args) {
        Triangle test = new Triangle(5, 10, 7);
    }
  }